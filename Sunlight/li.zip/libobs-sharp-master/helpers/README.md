Tools
============

* PrepareMonoVS: Prepares Mono targeting for Visual Studio, helps maintaining Mono compatibility.