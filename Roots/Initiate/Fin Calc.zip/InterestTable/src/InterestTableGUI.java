
import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import javafx.geometry.*;
import java.text.*;

@SuppressWarnings({"restriction", "static-access"})

public class InterestTableGUI extends Application{

	private TextArea result;
	private TextField principle, rate;
	private Button simple, compound, both;
	private Slider years;
	private int state = 0;
	
	@Override
	public void start(Stage primaryStage) {
		int sceneWidth = 700, sceneHeight = 400;
		
		//Creating the Pane and adding borders
		GridPane pane = new GridPane();
		pane.setHgap(10);
		pane.setVgap(10);
		pane.setPadding(new Insets(20, 20, 20, 20));
		
		//TextArea to display the results
		result = new TextArea();
		result.setEditable(false);
		pane.add(result, 0, 0, 4, 1);
		
		//TextFields to enter in the information
		Label principleLabel = new Label("Principle");
		principle = new TextField("1000");
		Label rateLabel = new Label("Rate(Percentage)");
		rate = new TextField("10");
		rate.setMaxWidth(160);
		pane.add(principleLabel, 0, 1);
		pane.setHalignment(principleLabel, HPos.RIGHT);
		pane.add(principle, 1, 1);
		pane.add(rateLabel, 2, 1);
		pane.setHalignment(rateLabel, HPos.RIGHT);
		pane.add(rate, 3, 1);
		
		//Slider for years
		Label yearsLabel = new Label("Number of Years");
		years = new Slider();
		years.setMin(1);
		years.setMax(25);
		years.setValue(10);
		years.setMajorTickUnit(4);
		years.setShowTickMarks(true);
		years.setShowTickLabels(true);
		pane.add(yearsLabel, 0, 2);
		pane.add(years, 1, 2, 3, 1);
		//ActionHandler for 'Number of Years' Slider
		years.valueProperty().addListener(e -> {
			//Determines with method of calculation and display based on the most recently clicked button
			if (state == 1) {
				simple.fire();
			}else if (state == 2) {
				compound.fire();
			}else if(state == 3) {
				both.fire();
			}
		});
		
		//Interest Buttons
		simple = new Button("Simple  Interest");
		simple.setMinWidth(150);
		pane.add(simple, 0, 3);
		simple.setOnAction(new SimpleButtonHandler());
		
		compound = new Button("Compund Interest");
		compound.setMinWidth(150);
		pane.add(compound, 1, 3);
		pane.setHalignment(compound, HPos.CENTER);
		//ActionHandler for 'Compound Interest' Button (Anonymous Inner)
		compound.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent e) {
				state = 2;
				double cPrinciple = Double.parseDouble(principle.getText());
				double cRate = Double.parseDouble(rate.getText());
				double cYears = years.getValue();
				//Heading
				String answer = "Principle: " + cPrinciple + ", Rate: " + cRate + "\n";
				answer += "Years, Compound Interst Amount\n";
		        DecimalFormat format = new DecimalFormat("0.00");
		        //Results for each year
				for (int i = 1; i <= cYears; i++) {
					String compoundInterest = format.format(Calculator.compoundInterestCalculator(cPrinciple, cRate, i));
					answer += i + " --> " + "$" + compoundInterest + "\n";
				}
				result.setText(answer);
			}
		});

		both = new Button("Both Interests");
		both.setMinWidth(150);
		pane.add(both, 2, 3);
		//ActionHandler(Lambda) for the 'Both Interests' Button
		both.setOnAction(e -> {
			state = 3;
			double cPrinciple = Double.parseDouble(principle.getText());
			double cRate = Double.parseDouble(rate.getText());
			double cYears = years.getValue();
			//Heading
			String answer = "Principle: " + cPrinciple + ", Rate: " + cRate + "\n";
			answer += "Years, Simple Interst Amount, Compound Interst Amount\n";
	        DecimalFormat format = new DecimalFormat("0.00");
	        //Results for each year
			for (int i = 1; i <= cYears; i++) {
				String simpleInterest = format.format(Calculator.simpleInterestCalculator(cPrinciple, cRate, i));
				String compoundInterest = format.format(Calculator.compoundInterestCalculator(cPrinciple, cRate, i));
				answer += i + " --> " + "$" + simpleInterest + " --> " + "$" + compoundInterest + "\n";
			}
			result.setText(answer);
		});
		
		/* Display the stage */
		Scene scene = new Scene(pane, sceneWidth, sceneHeight);
		primaryStage.setTitle("Interest Table Calculator");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		char a = '+';
		int xa = a;
		char b = '-';
		int xb = b;
		char c = '*';
		int xc = c;
		char d = '/';
		int xd = d;
		System.out.println(xa);
		System.out.println(xb);
		System.out.println(xc);
		System.out.println(xd);
		Application.launch(args);
	}
	

	//Handles updating the TextArea for the 'Simple Interest' Button (Non-anonymous Inner)
	private class SimpleButtonHandler implements EventHandler<ActionEvent> {

		public void handle(ActionEvent e) {
			state = 1;
			double cPrinciple = Double.parseDouble(principle.getText());
			double cRate = Double.parseDouble(rate.getText());
			double cYears = years.getValue();
			//Heading
			String answer = "Principle: " + cPrinciple + ", Rate: " + cRate + "\n";
			answer += "Years, Simple Interst Amount\n";
	        DecimalFormat format = new DecimalFormat("0.00");
	        //Results for each year
			for (int i = 1; i <= cYears; i++) {
				String simpleInterest = format.format(Calculator.simpleInterestCalculator(cPrinciple, cRate, i));
				answer += i + " --> " + "$" + simpleInterest + "\n";
			}
			result.setText(answer);
		}
	}
	
	//Contains the methods to calculate the interests for simplicity's sake
	static class Calculator{
		
		private static double simpleInterestCalculator(double principle, double rate, double years) {
			return principle + (principle * (rate / 100) * years);
		}

		private static double compoundInterestCalculator(double principle, double rate, double years) {
			return principle * Math.pow(1 + rate / 100, years);
		}
	}
}
